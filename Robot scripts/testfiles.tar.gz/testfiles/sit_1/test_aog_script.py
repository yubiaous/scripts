#Copyright Jon Berg , turtlemeat.com

import socket
import string,cgi,time
from os import curdir, sep
from SocketServer import BaseServer
from OpenSSL import SSL
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
#import pri

filename = "aogRsp.json"

class MyHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        try:
            print 'PRINT 1'
            f = open(filename,"r") #self.path has /test.html
            #self.path='/home/sudhendu/testScripts'
#note that this potentially makes every file on your computer readable by the internet
            fileContent = f.read();
            print fileContent
            f.close()
            print 'PRINT 2'
            self.send_response(200)
            self.send_header('Content-type','application/json')
            contentLen=len(fileContent) 
            self.send_header ("Content-Length", contentLen)
            self.end_headers()
            self.wfile.write(fileContent)
            #time.sleep(1000)   
            print 'PRINT 3'
            return
                
        except IOError:
            self.send_error(404,'File Not Found: %s' % self.path)

    def do_PUT(self):
        try:
            self.send_response(201)
            self.send_header('Content-type',	'text/xml')
            self.end_headers()
            #time.sleep(1000)   
            return
                
        except IOError:
            self.send_error(404,'File Not Found: %s' % self.path)
     

    def do_POST(self):
        global rootnode
        try:
            #ctype, pdict = cgi.parse_header(self.headers.getheader('content-type'))
            #if ctype == 'text/html':
            #  query=cgi.parse_multipart(self.rfile, pdict)
            f = open(filename,"r") #self.path has /test.html
            self.send_response(200)
            self.send_header("Content-type", 'application/x-www-form-urlencoded')
            #self.send_header("Content-type", 'text/xml')
	    self.send_header ("Content-Length", '998')
            str_path = self.path.split("/")[1]
            str_body = self.rfile
            print "str_path=",str_path,"end"
            print "str_body=",str_body,"end"
            self.end_headers()

            # upfilecontent = query.get('upfile')
            # print "filecontent", upfilecontent[0]
            # self.wfile.write("<HTML>POST OK.<BR><BR>");
            # self.wfile.write(upfilecontent[0]);
	    #time.sleep(1000)
            self.wfile.write(f.read())
            #self.wfile.write(f.read().replace("\t",""))
            f.close()
            
	    return 
	
       	except IOError:
       	    self.send_error(404,'File Not Found: %s' % self.path)

class SecureHTTPServer(HTTPServer):
    def __init__(self, server_address, HandlerClass):
        BaseServer.__init__(self, server_address, HandlerClass)
        ctx = SSL.Context(SSL.SSLv23_METHOD)
        #server.pem's location (containing the server private key and
        #the server certificate).
        fpem = 'server.pem'
        ctx.use_privatekey_file (fpem)
        ctx.use_certificate_file(fpem)
        self.socket = SSL.Connection(ctx, socket.socket(self.address_family,self.socket_type))
        self.server_bind()
        self.server_activate()

class HTTPServerV6(HTTPServer):
  address_family = socket.AF_INET6

def main():
    try:
        server = HTTPServerV6(('', 6418), MyHandler)
        print 'started httpserver...'
        server.serve_forever()
    except KeyboardInterrupt:
        print '^C received, shutting down server'
        server.socket.close()

if __name__ == '__main__':
    main()
