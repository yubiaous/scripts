#Copyright Jon Berg , turtlemeat.com

import socket
import string,cgi,time
from os import curdir, sep
from SocketServer import BaseServer
from OpenSSL import SSL
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
#import pri

filename = "AOG_RSP_FILE"

class MyHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        try:
            f = open(filename,"r") 
            fileContent = f.read();
            f.close()
            self.send_response(200)
            self.send_header('Content-type','application/json')
            contentLen=len(fileContent) 
            self.send_header ("Content-Length", contentLen)
            self.end_headers()
            self.wfile.write(fileContent)
            return
        except IOError:
            self.send_error(404,'File Not Found: %s' % self.path)

    def do_PUT(self):
        try:
            self.send_response(201)
            self.send_header('Content-type',	'text/xml')
            self.end_headers()
            return
                
        except IOError:
            self.send_error(404,'File Not Found: %s' % self.path)
     

    def do_POST(self):
        global rootnode
        try:
            f = open(filename,"r") #self.path has /test.html
            self.send_response(200)
            self.send_header("Content-type", 'application/x-www-form-urlencoded')
            self.send_header ("Content-Length", '998')
            str_path = self.path.split("/")[1]
            str_body = self.rfile
            print "str_path=",str_path,"end"
            print "str_body=",str_body,"end"
            self.end_headers()
            self.wfile.write(f.read())
            f.close()
            
	    return 
	
       	except IOError:
       	    self.send_error(404,'File Not Found: %s' % self.path)

class SecureHTTPServer(HTTPServer):
    def __init__(self, server_address, HandlerClass):
        BaseServer.__init__(self, server_address, HandlerClass)
        ctx = SSL.Context(SSL.SSLv23_METHOD)
        #server.pem's location (containing the server private key and
        #the server certificate).
        fpem = 'server.pem'
        ctx.use_privatekey_file (fpem)
        ctx.use_certificate_file(fpem)
        self.socket = SSL.Connection(ctx, socket.socket(self.address_family,self.socket_type))
        self.server_bind()
        self.server_activate()

class HTTPServerV6(HTTPServer):
  address_family = socket.AF_INET6

def main():
    try:
        server = HTTPServerV6(('', AOG_PORT), MyHandler)
        print 'started httpserver...'
        server.serve_forever()
    except KeyboardInterrupt:
        print '^C received, shutting down server'
        server.socket.close()

if __name__ == '__main__':
    main()
