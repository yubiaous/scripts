#!/usr/bin/python
import socket
import time

CLRF = '\r\n'

def connect_imap_socket(host,port):
	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	sock.connect((host, int(port)))
	return	sock

def send_data_to_imap_socket(sock,data):
	print "Sending data...... "+data
	sock.send(data)
	

def recieve_data_from_imap_socket(sock,timeout=60):
	sock.settimeout(timeout)
	try:
		data=sock.recv(65537)
	except socket.timeout:
		raise Exception ("Unable to recieve data within timeout")
	return	data

def close_imap_socket(sock):
	sock.close()
