#!/usr/bin/python
import socket
import mimetools
import datetime
import sys

rbufsize = -1
wbufsize = -1
class TestSocket():

	def open_socket(self,host,port):
		self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.sock.bind((host, int(port)))
		self.sock.listen(5)
		return	self.sock

	def get_one_request(self):
		self.req,self.cl_add=self.sock.accept()
		return self.req

	def read_request_body(self):
		rfile=self.req.makefile('rb', rbufsize)
		requestline = rfile.readline(65537)
		requestline = requestline.rstrip('\r\n')
		words = requestline.split()
		command, path, version = words
		self.protocol_version=version
		MessageClass = mimetools.Message
		headers = MessageClass(rfile, 0)
		con_len=headers.getheader('content-length', 0)
		req_body=rfile.read(int(con_len))
		rfile.close()
		return req_body

	def sendresponse_code(self,code,message):
		version_string="Python/"+sys.version.split()[0]
		Date_string=str(datetime.datetime.now())
		wfile=self.req.makefile('wb', wbufsize)
		wfile.write("%s %d %s\r\n" %(self.protocol_version, int(code), message))
		wfile.write("%s: %s\r\n" % ('Server', version_string))
		wfile.write("%s: %s\r\n" % ('Date', Date_string))
		wfile.flush()
		wfile.close()

	def close_socket(self):
		self.sock.close()



if __name__ == "__main__":
	testSock=TestSocket()	
	ip=raw_input("HOST:")
	port=raw_input("PORT:")
	sock=testSock.open_socket(ip,port)
	continue_flow=1
	while (continue_flow == 1 ):
		print "Waiting For the Request............."
		req=testSock.get_one_request()
		read_body=testSock.read_request_body()
		print "REQUEST BODY"
		print read_body
		print "VALIDATE and Send Response"
		response_code=raw_input("RESPONSE_CODE:")
		message=raw_input("Message:")		
		testSock.sendresponse_code(response_code,message)
		testSock.req.close()
		continue_flow=raw_input("Do you want to continue flow (1=:yes,0=no) :")

	testSock.close_socket()

