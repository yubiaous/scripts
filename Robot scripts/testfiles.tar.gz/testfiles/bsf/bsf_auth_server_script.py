#!/usr/bin/python
from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from SocketServer import ThreadingMixIn
import threading
import datetime

class Handler(BaseHTTPRequestHandler):
    
    def do_POST(self):
        content_len = int(self.headers.getheader('content-length', 0))
        self.req_body = self.rfile.read(content_len)
        now = datetime.datetime.now()
        #print "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
        #print now
        #print self.req_body
        f = open("bsf-rsp.xml","r")
        self.send_response(200)
        self.end_headers()
        self.wfile.write(f.read())
        f.close()

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""

if __name__ == '__main__':
    server = ThreadedHTTPServer(('10.10.29.45',5467), Handler)
    print 'Starting server, use <Ctrl-C> to stop'
    server.serve_forever()
