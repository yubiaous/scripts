#!/usr/bin/python
from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from SocketServer import ThreadingMixIn
import threading
import datetime

class Handler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        content_len = int(self.headers.getheader('content-length', 0))
        self.req_body = self.rfile.read(content_len)
        now = datetime.datetime.now()
        #print "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
        #print now
        #print self.req_body
        f = open("IAM_RESPONSE_FILE","r")
        self.send_response(200)
        self.end_headers()
        self.wfile.write(f.read())
        f.close()

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""

if __name__ == '__main__':
    server = ThreadedHTTPServer(('IAM_SERVER_IP',IAM_SERVER_PORT), Handler)
    print 'Starting server, use <Ctrl-C> to stop'
    server.serve_forever()
