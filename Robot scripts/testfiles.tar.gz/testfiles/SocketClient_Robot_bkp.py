#!/usr/bin/python
import socket
import time

CLRF = '\r\n'

def connect_socket(host,port):
	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	sock.connect((host, int(port)))
	return	sock

def send_data(sock,data):
	print "Sending data...... "+data
	sock.send(data)
	

def recieve_data(sock,timeout=60):
	sock.settimeout(timeout)
	try:
		data=sock.recv(65537)
	except socket.timeout:
		raise Exception ("Unable to recieve data within timeout")
	return	data

def close_client_socket(sock):
	sock.close()
