#!/usr/bin/python
import sys
simulator_server_ip=sys.argv[1]
simulator_server_port=sys.argv[2]

from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from SocketServer import ThreadingMixIn
import threading

class Handler(BaseHTTPRequestHandler):

    def do_POST(self):
        self.send_response(200)
        self.end_headers()
        message =  threading.currentThread().getName()
        self.wfile.write(message)
        self.wfile.write('\n')
        return

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""

if __name__ == '__main__':
    server = ThreadedHTTPServer((simulator_server_ip,int(simulator_server_port)), Handler)
    print 'Starting server, use <Ctrl-C> to stop'
    server.serve_forever()

