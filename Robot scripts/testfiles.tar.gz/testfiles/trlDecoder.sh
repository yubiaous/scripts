#!/bin/bash

usage () {
    echo ""
    echo "Usage: `basename $0` TRL_file [TRL_format]"
    echo ""
    exit 1
}

[ $# -eq 1 -o $# -eq 2 ] || usage

declare -i cnt
declare -i idx 
declare -a O_tlogFieldArr
cnt=1
file=$1

[ $# -eq 2 ] && format=$2
[ -z $format ] && format="trl_format"

for field in `cat $format`
do
    O_tlogFieldArr[$cnt]=$field
    cnt=`expr $cnt + 1` 
done

echo "************************************"
echo "Transaction Log Decoder"
echo "************************************"
echo "Tlog = "$file
echo "Format = "$format
echo $file
#for line in `cat $file`
while read line
do
idx=1
	echo $line > sam
	echo "******************************START OF TRL RECORD************************************************"
    while [ "$idx" -lt "$cnt" ]
    do
        printf "Field %d -  %60s -----> %s \n" $idx ${O_tlogFieldArr[$idx]} "`cat sam | cut -d "," -f$idx`"
        idx=`expr $idx + 1` 
    done
	echo "********************************END OF TRL RECORD************************************************"
done < $file

rm -rf sam
